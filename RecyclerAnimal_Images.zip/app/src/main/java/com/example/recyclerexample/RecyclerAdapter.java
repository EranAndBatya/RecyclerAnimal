package com.example.recyclerexample;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class RecyclerAdapter extends RecyclerView.Adapter<RecyclerAdapter.ImageViewHolder>
{

    private  int[] m_images;
    private String[] m_texts = {"פרה","תרנגולת","כלב","חמור","סוס","אריה","פיל","כבשה","קוף","חתול"};
    //Ctor
    public RecyclerAdapter(int[] images)
    {
        m_images = images;
    }

    @Override
    public ImageViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType)
    {
       View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.album_layout,parent,false);
       ImageViewHolder imageViewHolder = new ImageViewHolder(view);
       return  imageViewHolder;
    }

    @Override
    public void onBindViewHolder( ImageViewHolder holder, int position)
    {
     int image_id = m_images[position];
     holder.m_album_image.setImageResource(image_id);//טעינת התמונות לholder
     holder.m_album_title.setText(m_texts[position]);//טעינת הטקסט לholder

    }

    @Override
    public int getItemCount() {
        return m_images.length;
    }

    //-------------------------------------------------------------
    public static class ImageViewHolder extends RecyclerView.ViewHolder
    {
        ImageView m_album_image;
        TextView m_album_title;
        public ImageViewHolder(@NonNull View itemView)
        {
            super(itemView);
            m_album_image = itemView.findViewById(R.id.Image1);
            m_album_title = itemView.findViewById(R.id.Text1);

        }
    }
}
