package com.example.recyclerexample;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.os.Bundle;
import java.util.Arrays;
import java.util.List;


public class MainActivity extends AppCompatActivity {

    private RecyclerView m_recycleView;
    private int[] m_images = {R.drawable.para,
            R.drawable.chicken,
            R.drawable.dog,
            R.drawable.donkey,
            R.drawable.horse,
            R.drawable.lion,
            R.drawable.pil,
            R.drawable.sheep,
            R.drawable.monkey,
            R.drawable.cat};

    private RecyclerAdapter m_adapter;
    private RecyclerView.LayoutManager m_LayoutManager;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //קביעת המסך לתצוגה אנכית
        m_recycleView=findViewById(R.id.recyclerView);//קביעת כל המסך שאפשר לגלול
        m_LayoutManager=new GridLayoutManager(this,2);//מטריצה 2X2
        m_recycleView.setHasFixedSize(true);//המנעות משינוי תוכן גובה או רוחב של הפריטים
        m_recycleView.setLayoutManager(m_LayoutManager);
        m_adapter= new RecyclerAdapter(m_images);
        m_recycleView.setAdapter(m_adapter);//display

    }
}
